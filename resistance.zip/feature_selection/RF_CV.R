library(RSQLite)
library(ranger)

# Reading in data, change y for different traits, everythin else stays the same

splits <- read.table("assignment_sets.txt", header = T)
marker <- read.table("Marker_matrix_binary.csv", header = T, sep = ";"); m_info <- "snp"

y <- read.table("y/hs_br.txt", header = T, sep = ";"); y_info <- "br"
# y <- read.table("y/hs_fus1.txt",      sep = ";", header = T);  y_info = "fus1"
# y <- read.table("y/hs_septoria.txt",  sep = ";", header = T);  y_info = "septoria"
# y <- read.table("y/hs_md.txt",        sep = ";", header = T);  y_info = "md"
# y <- read.table("y/hs_yr.txt",        sep = ";", header = T);  y_info = "yr"


# Only necessary if you want to save it in a database
rfile  <- paste(y_info, m_info)
dbfile <- "RF_revised_fs2.sqldb"
add.df <- data.frame(method = "rf_fs", marker = m_info, run =0, trait = y_info, cor = 0, time = 0)

data <- cbind(y = y$yy, marker)

# Change PLINK file so it matches current trait
fam <- read.table("haploselekt-gwas.fam")
fam[,1] <- 0
fam[,6] <- y$yy
write.table(fam, "haploselekt-gwas.fam",quote = F, row.names = F, col.names = F)

# Use PLINK to generate the necessary files for GWAS, copied from Heinrich et al. script
system(command = paste0("tools/plink --bfile haploselekt-gwas --allow-no-sex --recode A --out brRawFile --chr-set ", 21), show.output.on.console = F)
rawData = data.table::fread("brRawFile.raw", header = T, data.table = F)
snpData = subset(rawData, select = -c(FID,IID,PAT,MAT,SEX))
colnames(snpData)[2:ncol(snpData)] = sub("_[^_]+$", "", colnames(snpData)[2:ncol(snpData)])

snpCount = ncol(rawData) - 6

# Steps used for incrementing number of features incldued
steps = c(seq(from = 100, to = 1000, by = 50),
    seq(from = 1100, to = 5000, by = 100),
    seq(from = 6000, to = snpCount, by = 1000),snpCount)


i=1;j=1
for(i in 1:200){
    # Assign training and test set according to our splits
    idx <- splits[,i] == "T"
    train <- rawData[idx,]
    test  <- rawData[!idx,]

    # Same for SNP data
    trainS <- snpData[idx,]
    testS  <- snpData[!idx,]

    # Get 5 folds
    sampleCount = nrow(train)
    sampleIndices = 1:sampleCount
    foldsIndices <- cut(sampleIndices,breaks=5,labels=FALSE)

    # Randomize order in the training datasets
    repeatIndices = sample(sampleIndices)
    train = train[repeatIndices,]
    trainS = trainS[repeatIndices,]
    
    resultAllSNPMatrix = matrix(nrow = 1, ncol = sampleCount, dimnames = list("AllSNPs", train$IID))
    resultMatrix = matrix(nrow = length(steps), ncol = sampleCount, dimnames = list(steps, train$IID))

    t0 <- Sys.time()
    
    for(j in 1:5){
        cat("Fold: ", j,"\n")

        # Choose as test all of fold j
        testIndices = which(foldsIndices == j, arr.ind = T)
        trainIndices = setdiff(1:nrow(train), testIndices)
        
        # Writing sample IDs for training in file for PLINK
        write.table(train[trainIndices,c("FID","IID")], file = "tempTrainingSetSampleIDs.txt", quote = F, row.names = F, col.names = F)
        
        # Running PLINK GWAS
        system(command = paste0("tools/plink --bfile haploselekt-gwas --allow-no-sex --assoc --out tempTrainingResult --keep tempTrainingSetSampleIDs.txt --chr-set 21"), show.output.on.console = F)
        
        # Read in PLINK result
        plinkResult = data.table::fread("tempTrainingResult.qassoc", header = T)
        orderedSNPs = plinkResult[order(plinkResult$P, decreasing = F),]$SNP
        
        # Prepare training and test data with sorted SNPs
        trainData = trainS[trainIndices, c("PHENOTYPE",orderedSNPs)]
        testData =  trainS[testIndices, c("PHENOTYPE",orderedSNPs)]
        
        # Run genomic prediction with all SNPs
        rf = ranger(x = subset(trainData, select =  -get("PHENOTYPE")), y = trainData[,1], num.threads = 10, num.trees = 500)
        predValues = predict(rf, testData)$predictions
        resultAllSNPMatrix[1,testIndices] = predValues
        
        # Run genomic prediction with incrementally added SNPs
        entryCounter = 1

        for(k in steps){
            cat("Number of SNPs: ", k,"\r")
            currentTrainData = trainData[,1:(k+1)]
            currentTestData = testData[,1:(k+1)]

            # Here, random forest is trained
            rf = ranger(x = subset(currentTrainData, select =  -get("PHENOTYPE")), y = currentTrainData[,1], num.threads = 10, num.trees = 500)
            predValues = predict(rf, currentTestData)$predictions
            resultMatrix[entryCounter,testIndices] = predValues
            entryCounter = entryCounter+1
        }
    }

    plot(apply(resultMatrix, 1, function(x) cor(x, train$PHENOTYPE)))
    bestStep <- which.max(apply(resultMatrix, 1, function(x) cor(x, train$PHENOTYPE)))
    k <- steps[bestStep]

    # Final model with best number of features
    rf = ranger(x = trainS[orderedSNPs[1:k]], y = trainS[,1], num.threads = 10, num.trees = 500)
    predValues = predict(rf, testS)$predictions
            
    t1 <- Sys.time()
    
    # Prediction accuracy
    add.df$cor <- cor(predValues, testS$PHENOTYPE)
    add.df$run <- i
    add.df$time <- as.numeric(difftime(t1, t0, units = 'mins'))
    add.df$step <- k

    pred.t <- as.data.frame(t(predValues))
    orig.t <- as.data.frame(t(testS$PHENOTYPE))

    # Write everything into database
    conn <- dbConnect(RSQLite::SQLite(), dbfile)
    sqliteSetBusyHandler(conn, 15000)
    dbWriteTable(conn, rfile, add.df, append=TRUE)
    dbWriteTable(conn, paste0(rfile,"_pred"),cbind(pred.t,i,m_info,y_info,data.x="rf_sel"), append =TRUE)
    dbDisconnect(conn)
}

